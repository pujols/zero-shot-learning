ImageNet_w2v.mat contains the following variables
1) 'wnids' and 'words': the synset ID and class names.
Note that, in the order 1-1000 are seen classes, 1001-2549 are 2-hop classes, 2550-8860 are pure 3-hop classes, 8861-21842 are the rest classes.
 
2) 'w2v': a 21842 x 500 matrix containing the word vectors correspoinding to 'wnids' and 'words'.

3) 'no_w2v_loc': the classes with no word vectors. For these classes, the corresponding rows in 'w2v' are all 0 vectors.

By removing the classes with no word vectors, 2-hop has 1509 classes, 3-hop (2-hop + pure 3-hop) has 7678 classes, and All (2-hop + pure 3-hop + rest) has 20345 classes.
For more details, please see our CVPR papers and the supplementary material.
                 
